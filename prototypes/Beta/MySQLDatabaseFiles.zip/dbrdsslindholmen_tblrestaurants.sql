CREATE DATABASE  IF NOT EXISTS `dbrdsslindholmen` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `dbrdsslindholmen`;
-- MySQL dump 10.13  Distrib 5.5.16, for Win32 (x86)
--
-- Host: localhost    Database: dbrdsslindholmen
-- ------------------------------------------------------
-- Server version	5.5.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tblrestaurants`
--

DROP TABLE IF EXISTS `tblrestaurants`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblrestaurants` (
  `rID` int(11) NOT NULL,
  `rName` varchar(45) DEFAULT NULL,
  `rStreet` varchar(45) DEFAULT NULL,
  `rStreetNumber` varchar(4) DEFAULT NULL,
  `rLat` double DEFAULT NULL,
  `rLng` double DEFAULT NULL,
  `rTelephoneNumber` varchar(45) DEFAULT NULL,
  `rEmail` varchar(45) DEFAULT NULL,
  `rHomepage` varchar(200) DEFAULT NULL,
  `rInfo` varchar(2500) DEFAULT NULL,
  `rOpen` time DEFAULT NULL,
  `rClose` time DEFAULT NULL,
  `UserID` int(11) DEFAULT NULL,
  PRIMARY KEY (`rID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblrestaurants`
--

LOCK TABLES `tblrestaurants` WRITE;
/*!40000 ALTER TABLE `tblrestaurants` DISABLE KEYS */;
INSERT INTO `tblrestaurants` VALUES (1,'Bistrot','Diagonalen','8',57.706583,11.938972,'031223323','catering@bistrot.se','','Welcome to the Bistro! Visit us at the pier at Lindholmen and enjoy a good lunch in good company. We serve lunch between the hours of 11:00 to 14:00.',NULL,NULL,NULL),(2,'Bombay Bistro','Lindholmsallén','35',57.708326,11.937737,NULL,'ind_89s@hotmail.com',NULL,'Bombay Bistro gives you the opportunity to taste Indian cuisine. Located right at the bus stop Lindholmen, a visit is never far away. Bombay Bistro offers not only a wide menu of Indian cuisine but laso lunch, take-away food and catering.','11:00:00','21:00:00',NULL),(3,'Café C','Lindholmspiren','5',57.707126,11.939794,NULL,NULL,NULL,'Café C is your coffee shop, you can visit from early morning to late afternoon every day. Hours are 7:30 a.m. to 4:00 p.m.. We offer both tasty take-aways and peace and quiet for those who want to sit down for a while. In our range you will find everything from coffee / tea for the meeting, pastries and cakes for celebrations, cakes to the 3 a clock break as sandwiches and salads for those who are on the go.',NULL,NULL,NULL),(4,'Café Kokboken','Forskningsgången','4',57.706214,11.936811,'0317723957','Linda@chalmerskonferens.se','http://www.chalmrest.se','Café Cookbook is in student union at Lindholmen. We offer coffee shop and bookstore with lunch at affordable student prices, where everyone is welcome. If you are a member of the Chalmers student union you can charge the card and take advantage of offers, lunch for 37 SEK (normal price 42 SEK) and contribute to a smoother flow. We also offer salads, sandwiches, candy, ice cream and homemade cakes. Welcome!',NULL,NULL,NULL),(5,'Café Mocka','Lindholmsallén','31',57.70868,11.938142,'0317192619',NULL,'http://www.cafemocka.se','Cafe Mocha serves everything from good breakfasts, main dishes, salads, hot & cold drinks. Hours: Monday-Friday. 08:00 to 19:00, Saturday. 11:00 to 18:00',NULL,NULL,NULL),(6,'Café Norra Älvstranden','Forskningsgången','6C',57.706632,11.937165,'031650230',NULL,NULL,'As a customer you may choose if you want Zoégas, Fairtrade Löfbergs purple or Gevalia in your cup for a cheap price without any extra charge for the fair-trade coffee. This is where many students and teachers come on their breaks. Pasta salad and smoothie are a popular part of our selection.',NULL,NULL,NULL),(7,'Encounter Asian Cuisine','Karlavagnsgatan','16',57.709276,11.937468,'0317880665',NULL,NULL,'Here you can encounter real yummy asian cuisine, from Sushi,Sashimi till hot meals, like YAKINIKU, YAKITORI, fried noodles. Also we have daily special someday. We always use fresh selected ingredients for all our foods. Coffee and tea are included in lunch.','10:00:00','15:30:00',NULL),(8,'Esters En Trappa Upp','Utvecklingsgatan','4',57.70515,11.936275,'0313672266','info.mosesson@educ.goteborg.se','http://www.goteborg.se/wps/portal/estermosessonsgymnasium','Restaurant with a combined buffet and table service (formerly Brasserie North Sea). Reservations 10:00 to 14:00 Tuesday to Friday.',NULL,NULL,NULL),(9,'Esters Salutorg','Lärdomsgatan','5',57.705603,11.936669,'0313672264','info.mosessons@educ.goteborg.se',NULL,'Everyone is welcome to Esther\'s market square. Students sell these products made in the Food Programme and the Hotel & Restaurant program at Esther Moses\'s High School.','08:30:00','15:00:00',NULL),(10,'Kapten Nemo´s Pizzeria Restaurang','Karlavagnsgatan','21',57.7079,11.93444,'031232464','','http://www.kaptennemos.se','Pizza, pasta, kebabs, salads, burgers and falafel!',NULL,NULL,NULL);
/*!40000 ALTER TABLE `tblrestaurants` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2012-11-26 22:46:12
