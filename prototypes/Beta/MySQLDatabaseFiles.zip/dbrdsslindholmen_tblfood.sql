CREATE DATABASE  IF NOT EXISTS `dbrdsslindholmen` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `dbrdsslindholmen`;
-- MySQL dump 10.13  Distrib 5.5.16, for Win32 (x86)
--
-- Host: localhost    Database: dbrdsslindholmen
-- ------------------------------------------------------
-- Server version	5.5.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tblfood`
--

DROP TABLE IF EXISTS `tblfood`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblfood` (
  `fID` int(11) NOT NULL,
  `fName` varchar(45) DEFAULT NULL,
  `fPrice` decimal(10,0) DEFAULT NULL,
  `fInfo` varchar(2500) DEFAULT NULL,
  `fType` varchar(45) DEFAULT NULL,
  `rID` int(11) DEFAULT NULL,
  PRIMARY KEY (`fID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblfood`
--

LOCK TABLES `tblfood` WRITE;
/*!40000 ALTER TABLE `tblfood` DISABLE KEYS */;
INSERT INTO `tblfood` VALUES (1,'Fläskstek',85,'serveras med rostad persiljepotatis, timjansky och mammas äpplechutney','Meat',1),(2,'Kalkonspett',85,' brie, valnötter, avokado samt dressing på rostad paprika','Turkey',1),(3,'Pasta Penne',85,'fläskfilé i gräddig pestosås toppad med salami och parmesan','Pasta',1),(4,'Sydafrikansk Fiskgryta',85,'fänkål och rotsaker samt parmesanbakad smördegs fleurong samt citrusaioli','Fish',1),(5,'Vesuvio',60,'tomatsås, ost och skinka','Pizza',2),(6,'Florida',70,'tomatsås, ost, skinka, räkor och ananas','Pizza',2),(7,'Husets',85,'tomatsås, ost, skinka, oxfilé, champinjoner, köttfärs och bearnaisesås','Pizza',2),(8,'Carbonara',75,'pasta med ostsås och bacon','Pasta',3),(9,'Pepparstekt fläskytterfilé',78,'med smakfull bearnaise','Meat',4),(10,'Ugnsbakad Laxfilé',78,'med vitvinsås och örtkryddad potatispuré','Fish',4),(11,'Italiensk Buffé',67,'Italiensk buffé','Buffé',5),(12,'Sallads Buffé',50,'Sallad buffé','Buffé',6),(13,'Crêpes',40,'Crêpes','Other',6),(14,'Lasagne',50,'Lasagne','Other',6),(15,'Pajer',45,'Olika pajer','Other',6),(16,'Dagens Soppa',50,'Dagens soppa med hembakat bröd','Soup',6),(17,'Entrecote Tyrolienne',74,'(bearnaise, tomatsås, lökringar) serveras m. klyftpotatis','Meat',7),(18,'Fetaostöverbakad Kycklingfilé',74,'m. paprika & mangosås serveras m. rosmarin stektpotatis','Chicken',7),(19,'Sesamstekt Laxfilé',74,'serveras m. wokade grönsaker & äggnudlar','Fish',7);
/*!40000 ALTER TABLE `tblfood` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2012-11-26 22:46:15
