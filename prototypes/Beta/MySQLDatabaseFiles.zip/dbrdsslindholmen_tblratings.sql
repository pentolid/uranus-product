CREATE DATABASE  IF NOT EXISTS `dbrdsslindholmen` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `dbrdsslindholmen`;
-- MySQL dump 10.13  Distrib 5.5.16, for Win32 (x86)
--
-- Host: localhost    Database: dbrdsslindholmen
-- ------------------------------------------------------
-- Server version	5.5.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tblratings`
--

DROP TABLE IF EXISTS `tblratings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblratings` (
  `rtID` int(11) NOT NULL AUTO_INCREMENT,
  `rtPoints` int(11) DEFAULT NULL,
  `rtComment` varchar(2500) DEFAULT NULL,
  `rtDate` timestamp NULL DEFAULT NULL,
  `uID` varchar(20) DEFAULT NULL,
  `rID` int(11) DEFAULT NULL,
  PRIMARY KEY (`rtID`)
) ENGINE=InnoDB AUTO_INCREMENT=87 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblratings`
--

LOCK TABLES `tblratings` WRITE;
/*!40000 ALTER TABLE `tblratings` DISABLE KEYS */;
INSERT INTO `tblratings` VALUES (1,3,'Pretty good food','2012-03-11 23:00:00','Nico',3),(2,5,'Awesome','2012-09-22 22:00:00','Nico',4),(28,1,'Crap!','2012-11-18 23:00:00','Nico',2),(29,4,'Awesome shit they have there!','2012-11-18 23:00:00','Nico',2),(30,3,'test','2012-11-19 13:15:54','Nico',2),(31,2,'Not so good...','2012-11-19 14:36:20','Carl',2),(33,5,'The best food I have ever had =)','2012-11-20 17:54:14','Nico',2),(44,2,'Okay for the price...','2012-11-20 18:44:54','Nico',2),(46,10,'Kebab #5!!!!! <3','2012-11-20 22:15:07','Nico',2),(47,2,'Not so good...','2012-11-20 22:17:50','Nico',4),(48,0,'Enter your comments here...\r\n		','2012-11-20 22:19:32','sefdsf',5),(72,4,'Nice Afterwork buffet on Fridays :)','2012-11-20 23:10:40','Nico',1),(73,5,'Awesome!','2012-11-20 23:12:36','Carl',10),(74,2,'Nothing special -.-','2012-11-20 23:13:04','Oskar',4),(77,4,'Very nice and cozy place. Unfortunately a little expensive since I am a student. But overall pretty good!\r\nPS: Check out the Irish Coffee! Awesome!','2012-11-21 09:18:11','somebody',6),(79,4,'Everything is really good and the prices are studentfriendly.','2012-11-22 03:25:42','Achmed',10),(80,4,'Nice pizza!','2012-11-23 10:37:19','Nico',10),(82,4,'Nice','2012-11-26 20:10:53','Nico',2);
/*!40000 ALTER TABLE `tblratings` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2012-11-26 22:46:10
