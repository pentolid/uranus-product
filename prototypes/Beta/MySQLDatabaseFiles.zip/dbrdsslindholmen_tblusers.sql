CREATE DATABASE  IF NOT EXISTS `dbrdsslindholmen` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `dbrdsslindholmen`;
-- MySQL dump 10.13  Distrib 5.5.16, for Win32 (x86)
--
-- Host: localhost    Database: dbrdsslindholmen
-- ------------------------------------------------------
-- Server version	5.5.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tblusers`
--

DROP TABLE IF EXISTS `tblusers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblusers` (
  `uID` varchar(20) NOT NULL,
  `uPassword` varchar(10) DEFAULT NULL,
  `uPermission` varchar(45) DEFAULT NULL,
  `uRegDate` datetime DEFAULT NULL,
  `uPref1` varchar(45) DEFAULT NULL,
  `uPref2` varchar(45) DEFAULT NULL,
  `uPref3` varchar(45) DEFAULT NULL,
  `uPref4` varchar(45) DEFAULT NULL,
  `uPref5` varchar(45) DEFAULT NULL,
  `tbluserscol` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`uID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblusers`
--

LOCK TABLES `tblusers` WRITE;
/*!40000 ALTER TABLE `tblusers` DISABLE KEYS */;
INSERT INTO `tblusers` VALUES ('',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('Nico','icecream','admin','2012-10-30 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),('Oskar','master','admin','2012-10-30 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),('Owner1','king','owner','2012-11-03 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),('Owner2','winning','owner','2012-11-01 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),('Owner3','toilet','owner','2012-11-02 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),('User1','noob','user','2012-11-09 00:00:00','Chicken','Pasta','','','',NULL),('User2','hungry','user','2012-11-11 00:00:00','Pizza','',NULL,NULL,NULL,NULL),('User3','baconboy','user','2012-11-23 00:00:00','Sallad','Chicken','Meat',NULL,NULL,NULL),('User4','georgebush','user','2012-11-13 00:00:00','Soup','Sallad',NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `tblusers` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2012-11-26 22:46:18
